# Mr. Magoo Mowing - Jekyll Site

This is a modular, responsive Jekyll website for Mr. Magoo Mowing landscaping services.

## Local Setup

1. Clone the repo
2. Run `bundle install`
3. Start local server:

```bash
bundle exec jekyll serve
```

Visit `http://localhost:4000` in your browser.

## Deployment

Can be deployed to GitHub Pages or any static hosting platform.